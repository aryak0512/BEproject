package com.example.MovieRecommender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRecommenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
